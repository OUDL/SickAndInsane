Want to use markdown instead?

`python render.py` can do that for you.

Dependencies: jinja2, markdown.
